﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESstaff.Models
{
    public class Token
    {
        public string Data { get; set; }
        public DateTime Expiration { get; set; }
    }
}
