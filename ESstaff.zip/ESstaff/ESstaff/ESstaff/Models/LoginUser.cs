﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ESstaff.Models
{
    public class LoginUser
    {
        public string EmailAddress { get; set; }

        public string Password { get; set; }
    }
}
