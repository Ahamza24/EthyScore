﻿namespace EsData.Models
{
    public class UserSummaryViewModel
    {
        public string Id { get; set; }
        public string FirstName { get; set; }
        public string SureName { get; set; }
        public string EmailAddress { get; set; }
    }
}
